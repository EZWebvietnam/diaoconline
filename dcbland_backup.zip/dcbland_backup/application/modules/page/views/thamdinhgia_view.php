<form  method="post" id="formV3" name="formV3" enctype="application/x-www-form-urlencoded">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="208" height="40px">Mã số tài sản trên DCBLAND.COM</td>
    <td width="412"><input type="text" name="msts" id="msts" class="lengMS" maxlength="6" /></td>
  </tr>
  <tr>
    <td width="208" height="40px">Địa chỉ tài sản</td>
    <td><input type="text" name="diachi" id="diachi" maxlength="200" class="lengInp"/></td>
  </tr>
  <tr>
    <td height="40px" colspan="2">Thông tin liên hệ: <img src="<?php echo base_url();?>template/home_ezwebvietnam/tham_dinh_gia/images/line.jpg" alt="" width="505" height="14" /></td></tr>
  <tr>
    <td width="208" height="40px">Họ tên</td>
    <td><input type="text" name="hoten" id="hoten" maxlength="100"  class="lengInp" /></td>
  </tr>
  <tr>
   <td width="208" height="40px">Số điện thoại</td>
    <td><input type="text" name="sdt" id="sdt" maxlength="50"  class="lengInp" /></td>
  </tr>
  <tr>
    <td width="208" height="40px">Email</td>
    <td><input type="text" name="email" id="email" maxlength="100"  class="lengInp" /></td>
  </tr>
  <tr>
    <td width="208" height="40px"></td>
    <td><img src="<?php echo base_url();?>template/home_ezwebvietnam/tham_dinh_gia/images/button.jpg" alt="" width="88" height="25" style="cursor:pointer;" id="imgsubmit" /></td>
  </tr>
</table>
    </form>