<div id="home_collection" class="wrap margin_bottom">
<div class="collection_type margin_bottom">
    <ul>
        <li><a href="/nha-dep/san-vuon-c5"><strong><span class="ico_16 ico_homeset_5_16"></span>Sân vườn</strong></a></li>
        <li><a href="/nha-dep/phong-khach-c8"><strong><span class="ico_16 ico_homeset_8_16"></span>Phòng khách</strong></a></li>
        <li><a href="/nha-dep/phong-lam-viec-c10"><strong><span class="ico_16 ico_homeset_10_16"></span>Phòng làm việc</strong></a></li>
        <li><a href="/nha-dep/nha-bep-c2"><strong><span class="ico_16 ico_homeset_2_16"></span>Nhà bếp</strong></a></li>
        <li><a href="/nha-dep/phong-ngu-c3"><strong><span class="ico_16 ico_homeset_3_16"></span>Phòng ngủ</strong></a></li>
        <li><a href="/nha-dep/phong-tre-em-c11"><strong><span class="ico_16 ico_homeset_11_16"></span>Phòng trẻ em</strong></a></li>
        <li><a href="/nha-dep/phong-tam-c6"><strong><span class="ico_16 ico_homeset_6_16"></span>Phòng tắm</strong></a></li>
        <li><a href="/nha-dep/noi-that-c7"><strong><span class="ico_16 ico_homeset_7_16"></span>Nội thất</strong></a></li>
        <li><a href="/nha-dep/mau-nha-c1"><strong><span class="ico_16 ico_homeset_1_16"></span>Mẫu nhà</strong></a></li>
        <li><a href="/nha-dep/khac-c12"><strong><span class="ico_16 ico_homeset_12_16"></span>Khác</strong></a></li>
    </ul>
</div>        <div class="paging_2 margin_bottom">
            <ul class="pager"><li><a href="javascript:void(0)" style="cursor:default;">«</a></li><li class="actived"><a href="javascript:void(0)">1</a></li><li><a href="/nha-dep/page/2" rel="next">2</a></li><li><a href="/nha-dep/page/3" rel="next">3</a></li><li><a href="/nha-dep/page/4" rel="next">4</a></li><li><a href="/nha-dep/page/5" rel="next">5</a></li><li><a href="/nha-dep/page/6" rel="next">6</a></li><li class="forward"><a rel="next" href="/nha-dep/page/2">»</a></li></ul>
<script type="text/javascript">
    $(function () {
        $('.pager').html(LoadPagging(1, 50, '/nha-dep'));
    });
</script>

        </div>
        <div class="wrap">
            <div class="block_3 ">
                <div class="img"><a href="/nha-dep/noi-that-c7/ai-noi-mau-xam-khong-thu-hut-i413"><img src="http://image.diaoconline.vn/nha-dep/2014/01/10/small-125-mauxam_1.jpg" alt="Ai nói màu xám không thu hút?" width="310" height="175"></a></div>
                <div class="body">
                    <h2><a href="/nha-dep/noi-that-c7/ai-noi-mau-xam-khong-thu-hut-i413">Ai nói màu xám không thu hút?</a></h2>
                    <a href="/nha-dep/noi-that-c7/ai-noi-mau-xam-khong-thu-hut-i413" class="grey_link">» Xem thêm <strong>8 hình</strong></a>
                </div>
            </div>
            <div class="block_3 ">
                <div class="img"><a href="/nha-dep/noi-that-c7/phong-cach-vintage-cho-can-nha-hien-dai-i412"><img src="http://image.diaoconline.vn/nha-dep/2014/01/10/small-004-phongcanh_1.jpg" alt="Phong cách Vintage cho căn nhà hiện đại" width="310" height="175"></a></div>
                <div class="body">
                    <h2><a href="/nha-dep/noi-that-c7/phong-cach-vintage-cho-can-nha-hien-dai-i412">Phong cách Vintage cho căn nhà hiện đại</a></h2>
                    <a href="/nha-dep/noi-that-c7/phong-cach-vintage-cho-can-nha-hien-dai-i412" class="grey_link">» Xem thêm <strong>22 hình</strong></a>
                </div>
            </div>
            <div class="banner_300x250 last">


            </div>
            <div class="block_3 ">
                <div class="img"><a href="/nha-dep/nha-bep-c2/nhung-mau-phong-an-dep-cho-khach-san-i411"><img src="http://image.diaoconline.vn/nha-dep/2014/01/09/small-C3F-phonganchokhachsan_14.jpg" alt="Những mẫu phòng ăn đẹp cho khách sạn" width="310" height="175"></a></div>
                <div class="body">
                    <h2><a href="/nha-dep/nha-bep-c2/nhung-mau-phong-an-dep-cho-khach-san-i411">Những mẫu phòng ăn đẹp cho khách sạn</a></h2>
                    <a href="/nha-dep/nha-bep-c2/nhung-mau-phong-an-dep-cho-khach-san-i411" class="grey_link">» Xem thêm <strong>19 hình</strong></a>
                </div>
            </div>
            <div class="block_3 ">
                <div class="img"><a href="/nha-dep/noi-that-c7/gay-an-tuong-bang-noi-that-mau-den-trong-phong-khach-i410"><img src="http://image.diaoconline.vn/nha-dep/2014/01/08/small-8C9-mauden_1.jpg" alt="Gây ấn tượng bằng nội thất màu đen trong phòng khách" width="310" height="175"></a></div>
                <div class="body">
                    <h2><a href="/nha-dep/noi-that-c7/gay-an-tuong-bang-noi-that-mau-den-trong-phong-khach-i410">Gây ấn tượng bằng nội thất màu đen trong phòng khách</a></h2>
                    <a href="/nha-dep/noi-that-c7/gay-an-tuong-bang-noi-that-mau-den-trong-phong-khach-i410" class="grey_link">» Xem thêm <strong>5 hình</strong></a>
                </div>
            </div>
            <div class="block_3  last">
                <div class="img"><a href="/nha-dep/phong-ngu-c3/mau-neon-cho-phong-ngu-ban-da-thu-chua-i409"><img src="http://image.diaoconline.vn/nha-dep/2014/01/08/small-C74-mauneon_6.jpg" alt="Màu Neon cho phòng ngủ - Bạn đã thử chưa?" width="310" height="175"></a></div>
                <div class="body">
                    <h2><a href="/nha-dep/phong-ngu-c3/mau-neon-cho-phong-ngu-ban-da-thu-chua-i409">Màu Neon cho phòng ngủ - Bạn đã thử chưa?</a></h2>
                    <a href="/nha-dep/phong-ngu-c3/mau-neon-cho-phong-ngu-ban-da-thu-chua-i409" class="grey_link">» Xem thêm <strong>6 hình</strong></a>
                </div>
            </div>
            <div class="block_3 ">
                <div class="img"><a href="/nha-dep/khac-c12/my-man-vi-goc-lam-viec-qua-phong-cach-i408"><img src="http://image.diaoconline.vn/nha-dep/2014/01/06/small-FEF-goclamviec_7.jpg" alt="Mỹ mãn vì góc làm việc quá phong cách" width="310" height="175"></a></div>
                <div class="body">
                    <h2><a href="/nha-dep/khac-c12/my-man-vi-goc-lam-viec-qua-phong-cach-i408">Mỹ mãn vì góc làm việc quá phong cách</a></h2>
                    <a href="/nha-dep/khac-c12/my-man-vi-goc-lam-viec-qua-phong-cach-i408" class="grey_link">» Xem thêm <strong>7 hình</strong></a>
                </div>
            </div>
            <div class="block_3 ">
                <div class="img"><a href="/nha-dep/noi-that-c7/ngam-can-ho-cuc-an-tuong-nho-phu-kien-sac-so-i407"><img src="http://image.diaoconline.vn/nha-dep/2014/01/06/small-57B-phukien_12.jpg" alt="Ngắm căn hộ cực ấn tượng nhờ phụ kiện sặc sỡ" width="310" height="175"></a></div>
                <div class="body">
                    <h2><a href="/nha-dep/noi-that-c7/ngam-can-ho-cuc-an-tuong-nho-phu-kien-sac-so-i407">Ngắm căn hộ cực ấn tượng nhờ phụ kiện sặc sỡ</a></h2>
                    <a href="/nha-dep/noi-that-c7/ngam-can-ho-cuc-an-tuong-nho-phu-kien-sac-so-i407" class="grey_link">» Xem thêm <strong>12 hình</strong></a>
                </div>
            </div>
            <div class="block_3  last">
                <div class="img"><a href="/nha-dep/noi-that-c7/nhung-mau-ghe-tuyet-dep-cho-ngoi-nha-them-xinh-i406"><img src="http://image.diaoconline.vn/nha-dep/2014/01/06/small-893-maughe_6.jpg" alt="Những mẫu ghế tuyệt đẹp cho ngôi nhà thêm xinh" width="310" height="175"></a></div>
                <div class="body">
                    <h2><a href="/nha-dep/noi-that-c7/nhung-mau-ghe-tuyet-dep-cho-ngoi-nha-them-xinh-i406">Những mẫu ghế tuyệt đẹp cho ngôi nhà thêm xinh</a></h2>
                    <a href="/nha-dep/noi-that-c7/nhung-mau-ghe-tuyet-dep-cho-ngoi-nha-them-xinh-i406" class="grey_link">» Xem thêm <strong>22 hình</strong></a>
                </div>
            </div>
        </div>
        <div class="paging_2">
             <ul class="pager"><li><a href="javascript:void(0)" style="cursor:default;">«</a></li><li class="actived"><a href="javascript:void(0)">1</a></li><li><a href="/nha-dep/page/2" rel="next">2</a></li><li><a href="/nha-dep/page/3" rel="next">3</a></li><li><a href="/nha-dep/page/4" rel="next">4</a></li><li><a href="/nha-dep/page/5" rel="next">5</a></li><li><a href="/nha-dep/page/6" rel="next">6</a></li><li class="forward"><a rel="next" href="/nha-dep/page/2">»</a></li></ul>
<script type="text/javascript">
    $(function () {
        $('.pager').html(LoadPagging(1, 50, '/nha-dep'));
    });
</script>

        </div>
    </div>