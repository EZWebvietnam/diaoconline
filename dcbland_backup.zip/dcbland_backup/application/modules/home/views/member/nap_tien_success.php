<div class="col_790 margin_left">
            <!-- InstanceBeginEditable name="content main" -->
            <div id="load_point" class="box">
                <div class="headline_11">
                    <h2>
                        NẠP ĐIỂM DOOL</h2>
                </div>
                <div class="body">
                 
                    
                    <div class="import_load_point">
                        <?php 
                        if(isset($error))
                        {
                            echo $error;
                        }
                        else
                        {
                            echo 'Denied';
                        }
                        ?>
                    </div>
                </div>
            </div>
            <!-- InstanceEndEditable -->
        </div>