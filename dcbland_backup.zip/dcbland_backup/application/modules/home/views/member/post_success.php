<div id="light" class="pop_up">
    <div class="pop_up_main">
        <div class="headline"><h2>THÔNG BÁO</h2></div>
            
        <div class="pop_up_main_inner">
            <h5 class="hightlight">Đăng tài sản thành công</h5>
            <div class="text">
                <p>Đăng tài sản thành công, tài sản cần được duyệt trước khi được kích hoạt trên hệ thống</p>
                <p class="info-title">Mã số tài sản: <span class="info-msts"><?php echo $code;?></span></p>
                
                
                <p>&nbsp;</p>
                <script type="text/javascript">
                    $(function () {
                        $('#p-load').text('');
                    });
                </script>
            </div>
            <div id="p-load"></div>
		    
        </div>
               
    </div>
</div>