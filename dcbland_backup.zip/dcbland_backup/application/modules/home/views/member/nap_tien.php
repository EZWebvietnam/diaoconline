<div class="col_790 margin_left">
            <!-- InstanceBeginEditable name="content main" -->
            <div id="load_point" class="box">
                <div class="headline_11">
                    <h2>
                        NẠP ĐIỂM DOOL</h2>
                </div>
                <div class="body">
                    <div id="card_agency" class="rounded_style_3 rounded_box margin_bottom"><div class="TL"></div><div class="TR"></div><div class="BL"></div><div class="BR"></div>
                        <div class="headline_12">
                            <h2>
                                Hiện tại hệ thống chỉ chấp nhận nạp tiền qua ví điện tử Ngân Lượng</strong></h2>
                        </div>
                        <div class="body">
                            <ul>
                                
                            </ul>
                        </div>
                    </div>
                    
                    <div class="import_load_point">
                        <form  method="post" class="form_style_3">
                        <ul>
                            <li>
                                <label>
                                    Hình thức <span class="hightlight">*</span></label>
                                <select id="ServiceList" name="ServiceList"><option selected="selected" value="-1">--- Chọn loại giao dịch ---</option>
<option value="1">Ngân Lượng</option>
<option value="2">Bảo Kim</option>
</select>
                            </li>
                            <li>
                                <label>
                                    Nhập mã số tiền <span class="hightlight">*</span></label>
                                <input class="keypress" id="code" name="code" type="text" value="">
                            </li>
                            <li>
                                <label>
                                    Code <span class="hightlight">*</span></label>
                                    <?php echo $code?>
                                <input  id="order_code" name="order_code" type="hidden" value="<?php echo $code?>">
                            </li>
                            
                            <li>
                                <button type="submit" class="btn_2">
                                    <span>NẠP ĐIỂM</span></button>
                                
                        </ul>
                        </form>
                    </div>
                </div>
            </div>
            <!-- InstanceEndEditable -->
        </div>