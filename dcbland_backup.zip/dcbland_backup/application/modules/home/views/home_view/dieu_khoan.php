<div class="qdC news-content bor-wrap">
        <p></p><h1>ĐIỀU KHOẢN THỎA THUẬN</h1><p></p>
            
        <div class="qdinhTop">
            Xin mời bạn hãy đọc cẩn thận Điều khoản Thoả thuận này trước khi truy cập vào 
            website <strong>DcbLand.com</strong>. Việc sử dụng hoặc truy cập vào website
            <strong>DcbLand.com</strong> sẽ được hiểu là sự chấp nhận và đồng ý ràng buộc 
            vào Điều khoản Thoả thuận. Nếu bạn có bất kỳ câu hỏi nào về Điều khoản Thoả 
            thuận này, xin hãy liên lạc với chúng tôi qua email <strong>info@DcbLand.com</strong></div>
        <div class="qdinhCon">
            <p class="font4">
                Điều Khoản Thoả Thuận truy cập website DcbLand.com</p>
            <p class="font3">
                Điều khoản Thoả thuận này được ký kết bởi và giữa <strong>DcbLand.com</strong> 
                với bất kỳ một cá nhân, công ty hoặc một thực thể nào khác, những người truy cập 
                hoặc sử dụng website <strong>DcbLand.com</strong> (được gọi chung là "Người 
                sử dụng” hoặc "bạn").<br>
                <br>
                <strong>DcbLand.com</strong> là một trang Web trên mạng Internet được thiết 
                kế cho phép thông tin về hoặc liên quan đến lĩnh vực Địa ốc, bao gồm cả việc 
                những người sử dụng đăng thông tin mua/bán/thuê/cho thuê địa ốc do những người 
                sử dụng khác đăng lên, hoặc tương tác với những người sử dụng đó. <strong>
                DcbLand.com</strong> do Công ty <strong>Cổ phần Địa Ốc Trực Tuyến</strong> sở 
                hữu và điều hành. <strong>DcbLand.com</strong> chứa hoặc có thể chứa các 
                thông tin, tin tức, các ý kiến, văn bản, đồ hoạ, các liên kết, sản phẩm nghệ 
                thuật điện tử, hình ảnh động, âm thanh, video, phần mềm, tranh ảnh, âm nhạc, 
                tiếng động và các nội dung, dữ liệu khác (gọi chung là "nội dung") được định 
                dạng, tổ chức và thu thập dưới nhiều hình thức khác nhau mà người sử dụng có thể 
                truy cập tới được, gồm thông tin trên website của <strong>DcbLand.com</strong> 
                mà người sử dụng có thể thay đổi được, chẳng hạn như đăng thông tin 
                mua/bán/thuê/cho thuê địa ốc/bất động sản, tải lên các tập tin đa phương tiện.</p>
            <p class="font1">
                1. Quyền hạng và trách nhiệm của người sử dụng</p>
            <p class="font5">
                A. Truy cập tới website DcbLand.com</p>
            <p class="font2">
                Bạn có trách nhiệm tự cung cấp tất cả phần cứng, phần mềm, số điện thoại hoặc 
                các thiết bị liên lạc khác và/hoặc dịch vụ kết nối tới Internet và truy cập tới
                <strong>DcbLand.com</strong>. đồng thời có trách nhiệm trả mọi khoản phí truy 
                cập Internet, phí điện thoại hoặc các khoản phí khác phát sinh trong quá trình 
                kết nối Internet và truy cập tới website <strong>DcbLand.com</strong>.</p>
            <p class="font5">
                B. Đạo đức người sử dụng</p>
            <p class="font2">
                Bạn đồng ý chỉ truy cập và dùng website <strong>DcbLand.com</strong> với các 
                mục đích hợp pháp. Bạn có trách nhiệm về việc hiểu biết và tuân thủ mọi điều 
                luật, các quy chế, quy tắc và các quy định gắn liền với: (i) việc bạn sử dụng 
                website <strong>DcbLand.com</strong>, kể cả vùng tương tác bất kỳ, (ii) việc 
                sử dụng mạng hay dịnh vụ nào khác có kết nối tới website <strong>DcbLand.com</strong> 
                và (iii) phương tiện liên lạc mà nhờ đó, bạn nối môđem, máy tính hoặc các thiết 
                bị khác của bạn tới website <strong>DcbLand.com</strong>. Truy cập tới 
                website <strong>DcbLand.com</strong>, bạn đồng ý bạn sẽ không:</p>
            <p class="font2">
                <img align="absmiddle" height="5" src="http://static.diaoconline.vn/images/ico_hd.gif" width="5">&nbsp;( 1) Hạn 
                chế hoặc ngăn cản người sử dụng khác sử dụng và hưởng các tính năng tương tác<br>
                <br>
                <img align="absmiddle" height="5" src="http://static.diaoconline.vn/images/ico_hd.gif" width="5">&nbsp;(2) Gửi 
                hoặc chuyển các thông tin bất hợp pháp, đe doạ, lạm dụng, bôi nhọ, nói xấu, 
                khiêu dâm, phi thẩm mỹ, xúc phạm hoặc bất kỳ loại thông tin không đúng đắn, bao 
                gồm truyền bá tin tức góp phần hay khuyến khích hành vi phạm tội, gây ra trách 
                nhiệm pháp lý dân sự hoặc vi phạm luật bất kỳ của một địa phương, bang, quốc 
                gia, hay luật quốc tế nào.<br>
                <br>
                <img align="absmiddle" height="5" src="http://static.diaoconline.vn/images/ico_hd.gif" width="5">&nbsp;(3) Gửi 
                hay chuyển các thông tin, phần mềm, hoặc các tài liệu khác bất kỳ, vi phạm hoặc 
                xâm phạm các quyền của những người khác, trong đó bao gồm cả tài liệu xâm phạm 
                đến quyền riêng tư hoặc công khai, hoặc tài liệu được bảo vệ bản quyền, tên 
                thương mại hoặc quyền sở hữu khác, hoặc các sản phẩm phái sinh mà không được sự 
                cho phép của người chủ sở hữu hoặc người có quyền hợp pháp.<br>
                <br>
                <img align="absmiddle" height="5" src="http://static.diaoconline.vn/images/ico_hd.gif" width="5">&nbsp;(4) Gửi 
                hoặc chuyển thông tin, phần mềm hoặc tài liệu bất kỳ có chứa virus hoặc một 
                thành phần gây hại khác<br>
                <br>
                <img align="absmiddle" height="5" src="http://static.diaoconline.vn/images/ico_hd.gif" width="5">&nbsp;(5) Thay 
                đổi, làm hư hại, xoá nội dung bất kỳ hoặc các phương tiện khác mà không phải là 
                nội dung thuộc sở hữu của bạn; hoặc gây trở ngại cho những người khác truy cập 
                tới website <strong>DcbLand.com</strong><br>
                <br>
                <img align="absmiddle" height="5" src="http://static.diaoconline.vn/images/ico_hd.gif" width="5">&nbsp;(6) Phá vỡ 
                luồng thông tin bình thường trong một tương tác<br>
                <br>
                <img align="absmiddle" height="5" src="http://static.diaoconline.vn/images/ico_hd.gif" width="5">&nbsp;(7)Tuyên 
                bố có liên hệ với hay phát ngôn cho một doanh nghiệp, hiệp hội, thể chế hay tổ 
                chức nào khác mà bạn không được uỷ quyền tuyên bố mối liên hệ đó<br>
                <br>
                <img align="absmiddle" height="5" src="http://static.diaoconline.vn/images/ico_hd.gif" width="5">&nbsp;(8) Vi 
                phạm một quy tắc, chính sách hay hướng dẫn sử dụng nào của nhà cung cấp dịch vụ 
                Internet cho bạn hay các dịch vụ trực tuyến</p>
            <p class="font1">
                2. Các quyền sở hữu trí tuệ</p>
            <p class="font3">
                (A) Bạn thừa nhận Nội dung trên website <strong>DcbLand.com</strong> nói 
                chung do <strong>DcbLand.com</strong>, cộng tác viên cá nhân về nội dung 
                ("Cộng tác viên"), người được cấp phép thứ ba, và/hoặc những người sử dụng khác 
                cung cấp. Bạn thừa nhận website <strong>DcbLand.com</strong> cho phép truy 
                cập tới Nội dung được bảo vệ bản quyền, tên thương mại và các quyền sở hữu khác 
                (kể cả quyền sở hữu trí tuệ) ("Quyền Sở hữu Trí tuệ"), và thừa nhận các quyền sở 
                hữu trí tuệ đó là hợp lệ và được bảo vệ trên mọi phương tiện truyền thông hiện 
                có và sau này, trừ những điểm nêu rõ ràng dưới đây, việc sử dụng nội dung của 
                bạn sẽ được quản lý theo các luật bản quyền và các luật sở hữu trí tuệ hiện hành 
                khác. Bạn thừa nhận website <strong>DcbLand.com</strong> sở hữu bản quyền 
                trong việc "xem và cảm nhận", có nghĩa là lựa chọn, hợp tác, sắp xếp và trình 
                bày nội dung đó.<br>
                <br>
                (B) Bạn không thể thay đổi, sao chép, mô phỏng, truyền, phân phối, công bố, tạo 
                ra các sản phẩm phái sinh, hiển thị hoặc chuyển giao, hoặc khai thác nhằm mục 
                đích thương mại bất kỳ phần nào của nội dung, toàn bộ hay từng phần, mặc dù bạn 
                có thể: (i) tạo một số lượng hợp lý các bản sao dưới dạng số hoặc hình thức khác 
                để phần cứng và phần mềm máy tính của bạn có thể truy cập và xem được nội dung, 
                (ii) in một bản sao của từng đoạn nội dung, (iii) tạo và phân phối một số lượng 
                hợp lý các bản sao nội dung, toàn bộ hay từng phần, ở dạng bản in hoặc bản điện 
                tử để dùng nội bộ. Bất kỳ bản sao nội dung được phép nào cũng phải được tái tạo 
                ở dạng không thể biến đổi được các thông tri bất kỳ chứa trong nội dung, chẳng 
                hạn như tất cả các thông tri về Quyền Sở hữu Trí tuệ, và các nguồn thông tin ban 
                đầu cho “website <strong>DcbLand.com</strong>” và địa chỉ mạng (URL) của nó. 
                Bạn thừa nhận, website <strong>DcbLand.com</strong>, các cộng tác viên, 
                và/hoặc những người sử dụng vẫn là những người chủ sở hữu của nội dung và rằng, 
                bạn sẽ không có bất kỳ Quyền Sở hữu Trí tuệ nào qua việc tải xuống hoặc in nội 
                dung.</p>
            <p class="font4">
                Nội dung do Người sử dụng cung cấp</p>
            <p class="font3">
                Bạn chỉ có thể tải lên vùng tương tác bất kỳ hoặc truyền, gửi, công bố, mô phỏng 
                hoặc phân phối trên hoặc thông qua website <strong>DcbLand.com</strong> phần 
                nội dung, không phụ thuộc vào bất kỳ Quyền Sở hữu Trí tuệ nào, hoặc nội dung mà 
                người giữ Quyền Sở hữu Trí tuệ có sự ủy quyền rõ ràng về việc phân tán trên 
                Internet và trên website <strong>DcbLand.com</strong> mà không có hạn chế gì. 
                Mọi nội dung được đưa ra với sự đồng ý của người sở hữu bản quyền không phải là 
                bạn phải kèm theo câu như “do [tên người chủ sở hữu] sở hữu bản quyền; được dùng 
                theo ủy quyền”.<br>
                <br>
                Với việc đưa nội dung lên vùng tương tác bất kỳ, bạn tự động chấp nhận và/hoặc 
                cam đoan rằng, chủ sở hữu của nội dung đó , hoặc là bạn, hoặc là nhóm thứ ba, đã 
                cho website <strong>DcbLand.com</strong> quyền và giấy phép không phải trả 
                tiền bản quyền, lâu dài, không thay đổi, không loại trừ, không hạn chế để sử 
                dụng, mô phỏng, thay đổi, sửa lại, công bố, dịch thuật, tạo các sản phẩm phái 
                sinh, cấp phép con, phân phối, thực hiện và hiển thị nội dung đó, toàn phần hay 
                từng phần, khắp thế giới và/hoặc kết hợp nó với các công việc khác ở dạng bất 
                kỳ, qua các phương tiện truyền thông hoặc công nghệ hiện tại hay sẽ phát triển 
                sau này theo điều khoản đầy đủ của Quyền Sở hữu Trí tuệ bất kỳ trong nội dung 
                đó. Bạn cũng cho phép website <strong>DcbLand.com</strong> cấp giấy phép con 
                cho bên thứ ba quyền không hạn chế để thực hiện bất kỳ quyền nào ở trên với nội 
                dung đó. Bạn cũng cho phép người dùng truy cập, xem, lưu và mô phỏng lại nội 
                dung để sử dụng riêng. Bạn cũng cho phép website <strong>DcbLand.com</strong> 
                dùng tên và logo công ty vì các mục đích tiếp thị</p>
            <p class="font1">
                3. Các vùng tương tác</p>
            <p class="font3">
                Bạn thừa nhận, website <strong>DcbLand.com</strong> có thể chứa các vùng 
                tương tác khác nhau. Những vùng tương tác này cho phép phản hồi tới website
                <strong>DcbLand.com</strong> và tương tác thời gian thực giữa những người sử 
                dụng. Bạn cũng hiểu rằng, website <strong>DcbLand.com</strong> không kiểm 
                soát các thông báo, thông tin hoặc các tập tin được phân phối tới các vùng tương 
                tác như vậy và rằng, website <strong>DcbLand.com </strong>có thể cho bạn và 
                những người sử dụng khác khả năng tạo và quản lý một vùng tương tác.<br>
                <br>
                Tuy nhiên, website <strong>DcbLand.com</strong>, công ty mẹ, hoặc các chi 
                nhánh, cũng như các giám đốc, nhân viên, những người làm thuê và các đại lý 
                tương ứng không chịu trách nhiệm về nội dung trong vùng tương tác bất kỳ. Việc 
                sử dụng và quản lý một vùng tương tác của bạn sẽ bị chi phối bởi Điều khoản Thoả 
                thuận này và các quy tắc bổ sung bất kỳ, hoặc bởi các thủ tục hoạt động của vùng 
                tương tác bất kỳ do bạn hay người sử dụng khác thiết lập. Bạn công nhận rằng, 
                website <strong>DcbLand.com</strong> không thể và không có ý định sàng lọc 
                các thông tin trước. Ngoài ra, vì website <strong>DcbLand.com</strong> khuyến 
                khích liên lạc mở và không thiên vị trong các vùng tương tác nên website <strong>
                DcbLand.com</strong> không thể xác định trước mức độ chính xác hoặc sự phù 
                hợp đối với Điều khoản Thoả thuận này về nội dung bất kỳ được chuyển đi trong 
                vùng tương tác.<br>
                <br>
                Website <strong>DcbLand.com</strong> không chịu trách nhiệm với việc sàng 
                lọc, lập chính sách, hiệu chỉnh, duyệt hoặc giám sát nội dung bất kỳ trong một 
                vùng tương tác. Mặc dù vậy, bạn cũng đồng ý rằng website <strong>DcbLand.com</strong> 
                có quyền giám sát mọi vùng tương tác, đôi lúc để lộ thông tin nào đó nếu cần 
                thiết theo yêu cầu luật pháp, hoặc yêu cầu khác của chính phủ đối với hoạt động 
                của vùng tương tác, hoặc để tự bảo vệ mình hay những người sử dụng khác. Nếu 
                được thông báo nội dung dẫn ra không phù hợp với bản Thỏa thuận này, website
                <strong>DcbLand.com</strong> có thể thận trọng điều tra và xác định để loại 
                bỏ, hoặc yêu cầu người sử dụng bỏ nội dung đó. Website <strong>DcbLand.com</strong> 
                giữ quyền cấm các hành động, truyền đạt tin tức hoặc nội dung trong phạm vi vùng 
                tương tác, hoặc soạn thảo, từ chối gửi, hoặc loại bỏ nội dung bất kỳ, toàn thể 
                hay từng phần mà với đặc quyền của mình, chúng tôi cho rằng (i) vi phạm các điều 
                khoản tiêu chuẩn lúc đó của bản Thỏa thuận này hoặc chuẩn bất kỳ khác nằm trong 
                chính sách của <strong>DcbLand.com</strong> vẫn còn hiệu lực vào lúc đó, (ii) 
                bất lợi với các quyền của mọi người sử dụng, của website <strong>DcbLand.com</strong> 
                hoặc các nhóm thứ ba khác, (iii) vi phạm luật hiện hành hoặc (iv) những điều 
                không hay khác.</p>
            <p class="font1">
                4. Chấm dứt</p>
            <p class="font3">
                Quyền duy nhất của bạn khi không thỏa mãn với mọi chính sách, nguyên tắc chỉ đạo 
                hay hành động thực tiễn của website <strong>DcbLand.com</strong> trong điều 
                hành <strong>DcbLand.com</strong>, hoặc mọi thay đổi về nội dung là dừng sự 
                truy cập tới website <strong>DcbLand.com</strong>. Website <strong>
                DcbLand.com</strong> có thể chấm dứt hoặc tạm thời ngưng sự truy cập của bạn 
                đến tất cả hay phần bất kỳ của website <strong>DcbLand.com</strong> mà không 
                thông báo với các hành động khi <strong>DcbLand.com</strong> tin là vi phạm 
                Điều khoản Thỏa thuận này hoặc vi phạm mọi chính sách hay nguyên tắc chỉ đạo mà 
                website <strong>DcbLand.com</strong> đã đưa ra, hoặc với các hành động khác 
                mà DcbLand.com tin là có hại đến website <strong>DcbLand.com</strong> và 
                những người sử dụng khác.<br>
                <br>
                Website <strong>DcbLand.com</strong> với đặc quyền riêng có thể đình chỉ sự 
                hoạt động của nó và chấm dứt Điều khoản Thỏa thuận này mà không thông báo vào 
                bất kỳ lúc nào và vì bất kỳ lý do nào theo đặc quyền của mình. Trong trường hợp 
                chấm dứt, bạn không còn được phép truy cập đến website DcbLand.com nữa, kể cả 
                các vùng tương tác và các hạn chế của bạn về nội dung đươc tải xuống từ <strong>
                DcbLand.com</strong>, cũng như những từ chối về quyền lợi và các giới hạn về 
                các trách nhiệm pháp lý được nêu ra trong thỏa thuận này, vẫn còn giá trị.</p>
            <p class="font1">
                5. Các liên kết; các từ chối các cam kết; các giới hạn về trách nhiệm pháp lý</p>
            <p class="font4">
                Các liên kết</p>
            <p class="font3">
                Bạn hiểu rằng trừ phần nội dung, các sản phẩm và dịch vụ có trên website <strong>
                DcbLand.com</strong>, DcbLand.com, công ty mẹ, hoặc các chi nhánh, cũng 
                như các giám đốc, nhân viên, người làm công và các đại lý tương ứng kiểm soát, 
                cung cấp không chịu trách nhiệm với nội dung, hàng hóa hoặc các dịch vụ của các 
                sites khác trên Internet được kết nối tới hoặc từ website <strong>DcbLand.com</strong>. 
                Tất cả nội dung, hàng hóa và các dịch vụ đó đều có thể truy cập được trên 
                Internet bởi bên thứ ba độc lập và không phải là một phần của website <strong>
                DcbLand.com</strong> hoặc được kiểm soát bởi DcbLand.com. Website <strong>
                DcbLand.com</strong> không xác nhận và cũng không chịu trách nhiệm về tính 
                chính xác, tính đầy đủ, tính hữu dụng, chất lượng và tính sẵn sàng của mọi nội 
                dung, hàng hóa hay các dịch vụ có trên các site được kết nối tới hoặc từ website 
                DcbLand.com mà đó là trách nhiệm duy nhất của bên thứ ba độc lập đó, và do 
                vậy việc sử dụng của bạn là sự mạo hiểm riêng của bạn. Website <strong>
                DcbLand.com</strong>, công ty mẹ, hoặc các chi nhánh, hoặc các giám đốc, nhân 
                viên, người làm công và các đại lý tương ứng không chịu trách nhiệm pháp lý, 
                trực tiếp hay gián tiếp, với mọi mất mát hay thiệt hại gây ra bởi hoặc bị cho là 
                gây ra bởi việc sử dụng hoặc sự tin cậy của bạn vào mọi nội dung, hàng hóa hoặc 
                các dịch vụ có trên site bất kỳ được kết nối đến hoặc từ website DcbLand.com, 
                hoặc do bạn không thể truy cập lên Internet hay site bất kỳ kết nối đến hoặc từ 
                website <strong>DcbLand.com</strong>.</p>
            <p class="font4">
                Từ chối các bảo đảm</p>
            <p class="font3">
                Xin hãy dùng sự suy xét tốt nhất của bạn trong việc đánh giá tất cả các thông 
                tin hoặc các ý kiến được trình bày trên website <strong>DcbLand.com</strong>. 
                Chính sách của website DcbLand.com không xác nhận hay phản đối mọi ý kiến do 
                người sử dụng bày tỏ, hoặc nội dung do người sử dụng, cộng tác viên hoặc nhóm 
                độc lập khác cung cấp. BẠN ĐỒNG Ý RÕ RÀNG RẰNG VIỆC SỬ DỤNG website 
                DcbLand.com LÀ SỰ MẠO HIỂM CỦA RIÊNG BẠN. Website <strong>DcbLand.com</strong>, 
                VÀ CÔNG TY MẸ, HOẶC CÁC CHI NHÁNH, HOẶC CÁC GIÁM ĐỐC, NHÂN VIÊN, NHỮNG NGƯỜI LÀM 
                THUÊ, CÁC ĐẠI LÝ, CÁC CỘNG TÁC VIÊN, HỘI VIÊN, NGƯỜI CẤP PHÉP HOẶC CÁC NHÀ CUNG 
                CẤP KHÁC CUNG CẤP NỘI DUNG, DỮ LIỆU, THÔNG TIN HOẶC CÁC DỊCH VỤ KHÔNG BẢO ĐẢM 
                RẰNG, website DcbLand.com HOẶC MỌI SITE INTERNET ĐƯỢC KẾT NỐI ĐẾN HOẶC TỪ 
                website DcbLand.com SẼ KHÔNG BỊ NGẮT QUÃNG HOẶC BỊ SAI SÓT, RẰNG CÁC NHƯỢC 
                ĐIỂM SẼ ĐƯỢC SỬA CHỮA, HOẶC WEBSITE NÀY, KỂ CẢ CÁC VÙNG TƯƠNG TÁC HOẶC MÁY CHỦ 
                TẠO RA NÓ KHÔNG BỊ NHIỄM VIRUS HAY CÁC THÀNH PHẦN GÂY HẠI KHÁC. VÀ CHÚNG TÔI 
                CŨNG KHÔNG BẢO ĐẢM VỀ CÁC KẾT QUẢ NHẬN ĐƯỢC TỪ VIỆC SỬ DỤNG website 
                DcbLand.com HOẶC VỀ TÍNH ĐÚNG LÚC, TÍNH TRÌNH TỰ, TÍNH CHÍNH XÁC, SỰ ỦY 
                QUYỀN, TÍNH ĐẦY ĐỦ, TÍNH HỮU DỤNG, TÍNH BẤT KHẢ XÂM PHẠM, TÍNH TIN CẬY, TÍNH SẴN 
                SÀNG HOẶC TÍNH CHẮC CHẮN CỦA MỌI NỘI DUNG, THÔNG TIN, DỊCH VỤ HOẶC GIAO DỊCH 
                ĐƯỢC CUNG CẤP QUA website DcbLand.com HOẶC MỌI SITE ĐƯỢC KẾT NỐI ĐẾN HOẶC TỪ 
                website DcbLand.com. Website <strong>DcbLand.com</strong> ĐƯỢC CUNG CẤP 
                TRÊN CƠ SỞ “VỚI TƯ CÁCH LÀ”, “NẾU CÓ” MÀ KHÔNG CÓ BẤT KỲ ĐẢM BẢO THEO HÌNH THỨC 
                NÀO, RÕ RÀNG HAY NGỤ Ý, BAO GỒM NHƯNG KHÔNG HẠN CHẾ, CÁC VẤN ĐỀ CÓ TÍNH THƯƠNG 
                MẠI HAY PHÙ HỢP CHO MỘT MỤC ĐÍCH CỤ THỂ.</p>
            <p class="font4">
                Giới hạn về trách nhiệm pháp lý</p>
            <p class="font3">
                TRONG BẤT KỲ TRƯỜNG HỢP NÀO, website <strong>DcbLand.com</strong>, CÔNG TY 
                MẸ, HOẶC CÁC CHI NHÁNH, HOẶC CÁC GIÁM ĐỐC, NHÂN VIÊN, NHỮNG NGƯỜI LÀM THUÊ, CÁC 
                ĐẠI LÝ, CÁC CỘNG TÁC VIÊN, HOẶC NHỮNG NGƯỜI CẤP PHÉP KHÔNG CHỊU TRÁCH NHIỆM PHÁP 
                LÝ VỚI MỌI THIỆT HẠI NGẪU NHIÊN, ĐẶC BIỆT HAY ĐƯƠNG NHIÊN THEO HOẶC NẢY SINH TỪ 
                BẢN THỎA THUẬN NÀY, website <strong>DcbLand.com</strong> HOẶC MỌI SITE 
                INTERNET ĐƯỢC KẾT NỐI ĐẾN HOẶC TỪ website DcbLand.com, VÌ LÝ DO VI PHẠM HỢP 
                ĐỒNG, ỨNG XỬ SAI LẦM, SƠ XUẤT HOẶC BẤT KỲ NGUYÊN NHÂN HÀNH ĐỘNG KHÁC NÀO, BAO 
                GỒM NHƯNG KHÔNG HẠN CHẾ MỌI NGHĨA VỤ PHÁP LÝ CHO MỌI THIỆT HẠI GÂY BỞI HOẶC CHO 
                LÀ GÂY BỞI MỌI THIẾU SÓT TRONG THỰC HIỆN, LỖI BỎ SÓT, GIÁN ĐOẠN, SỰ ĐỘT 
                BIẾN/HỎNG HÓC/NHIỄU ĐIỆN, VIỆC XÓA, CHẬM TRỄ TRONG HOẠT ĐỘNG HOẶC CHUYỂN TẢI, VI 
                RÚT MÁY TÍNH, HỎNG ĐƯỜNG LIÊN LẠC, HỎNG THIẾT BỊ, LỖI PHẦN MỀM, VI PHẠM, TRUY 
                CẬP TRÁI PHÉP, HOẶC TRỘM CẮP, PHÁ HOẠI, THAY THẾ, HOẶC SỬ DỤNG CÁC BẢN GHI. 
                TRONG BẤT KỲ TRƯỜNG HỢP NÀO, website DcbLand.com, CÔNG TY MẸ, HOẶC CÁC CHI 
                NHÁNH, HOẶC CÁC GIÁM ĐỐC, NHÂN VIÊN, NHỮNG NGƯỜI LÀM THUÊ, CÁC ĐẠI LÝ, CÁC CỘNG 
                TÁC VIÊN HOẶC NHỮNG NGƯỜI CẤP PHÉP KHÔNG CHỊU TRÁCH NHIỆM PHÁP LÝ ĐỐI VỚI BẠN 
                HOẶC MỌI NHÓM THỨ BA KHÁC VỀ MỘI QUYẾT ĐỊNH ĐÃ RA HOẶC HÀNH ĐỘNG MÀ BẠN THỰC 
                HIỆN VÌ TIN VÀO NỘI DUNG CHỨA TRONG website <strong>DcbLand.com</strong> HOẶC 
                NỘI DUNG CHỨA ĐỰNG TRONG PHẠM VI MỌI SITE INTERNET ĐƯỢC KẾT NỐI VỚI HOẶC TỪ 
                website DcbLand.com. NỘI DUNG TRONG PHẠM VI website DcbLand.com VÀ NỘI 
                DUNG TRONG PHẠM VI CÁC SITE INTERNET ĐƯỢC KẾT NỐI ĐẾN HOẶC TỪ website 
                DcbLand.com CÓ THỂ CÓ LỖI KỸ THUẬT, CÁC LỖI KHÔNG CHÍNH XÁC KHÁC, HOẶC CÁC 
                LỖI IN. CÁC THAY ĐỔI ĐƯỢC BỔ SUNG ĐỊNH KỲ VÀO NỘI DUNG TRONG ĐÂY, NHỮNG THAY ĐỔI 
                NÀY SẼ ĐƯỢC CẬP NHẬT TRONG CÁC PHIÊN BẢN MỚI CỦA website <strong>DcbLand.com</strong> 
                VÀ ĐẶC BIỆT ĐƯỢC BAO HÀM TRONG BẢN THOẢ THUẬN NÀY. Website DcbLand.com VÀ CÁC 
                CỘNG TÁC VIÊN CÓ THỂ CÓ NHỮNG CẢI TIẾN VÀ/HOẶC CÁC THAY ĐỔI VỀ NỘI DUNG VÀO BẤT 
                KỲ LÚC NÀO. BẠN ĐỒNG Ý VÀ THỪA NHẬN RÕ RÀNG RẰNG, website DcbLand.com KHÔNG 
                CHỊU TRÁCH NHIỆM PHÁP LÝ VỚI MỌI HÀNH VI NÓI XẤU, TẤN CÔNG, KHÔNG TRUNG THỰC 
                HOẶC CÁC HÀNH VI BẤT HỢP PHÁP KHÁC CỦA NGƯỜI SỬ DỤNG BẤT KỲ. NẾU BẠN KHÔNG BẰNG 
                LÒNG VỚI BẤT KỲ NỘI DUNG NÀO CỦA website <strong>DcbLand.com</strong>, HOẶC 
                VỚI GIAO KÈO TRUY CẬP CỦA website DcbLand.com, TOÀN BỘ HAY TỪNG PHẦN, THÌ 
                BIỆN PHÁP DUY NHẤT CỦA BẠN LÀ THÔI KHÔNG SỬ DỤNG website DcbLand.com NỮA.</p>
            <p class="font1">
                6. Bồi thường</p>
            <p class="font3">
                Bạn đồng ý trả tiền và miễn cho website <strong>DcbLand.com</strong>, công ty 
                mẹ và các chi nhánh, các giám đốc, nhân viên, những người làm công và các đại lý 
                tương ứng tất cả các trách nhiệm pháp lý, các quyền được đòi hỏi và các phí tổn, 
                kể cả các phí hợp lý cho luật sư, nảy sinh từ sự vi phạm Điều khoản Thỏa thuận 
                này, từ chính sách bất kỳ khác, từ việc sử dụng hay truy cập của bạn tới website
                <strong>DcbLand.com </strong>hoặc site internet đựơc kết nối đến hoặc từ 
                website <strong>DcbLand.com</strong>, hoặc về việc truyền nội dung bất kỳ 
                trên website DcbLand.com.</p>
            <p class="font1">
                7. Các vấn đề khác</p>
            <p class="font3">
                Điều khoản Thoả thuận này bao gồm toàn bộ sự thoả thuận giữa website <strong>
                DcbLand.com</strong> và bạn, và thay thế mọi thoả thuận trước đây về chủ đề 
                này. Website DcbLand.com có thể xét lại Điều khoản Thoả thuận này hoặc mọi 
                chính sách khác vào bất cứ lúc nào và đôi khi, sự xem xét lại này sẽ có hiệu lực 
                trong 2 ngày nhờ gửi thông báo về sự xem xét lại đó ở nơi dễ thấy trên website
                <strong>DcbLand.com</strong>. Bạn đồng ý xem xét lại Điều khoản Thoả thuận 
                này định kỳ để hiểu về những điều đã được sửa lại đó. Nếu bạn không chấp nhận 
                các sửa đổi này, bạn phải thôi truy cập tới website DcbLand.com. Sự tiếp tục 
                truy cập của bạn và việc sử dụng website <strong>DcbLand.com</strong> sau 
                thông báo về mọi sửa đổi như vậy sẽ được coi chắc chắn là sự chấp nhận tất cả 
                các sửa đổi như vậy. Các điều khoản của các mục 1.2, 2.1, 2.2, 5.1, 5.2, 5.3, 6 
                và 7 sẽ vẫn còn lại sau sự chấm dứt hoặc kết thúc Điều khoản Thoả thuận này. Nếu 
                điều khoản bất kỳ của Điều khoản Thoả thuận này hoặc của mọi chính sách khác 
                không có căn cứ hoặc không thể thực hiện được, thì phần nội dung đó cần được 
                hiểu, theo luật hiện hành gần nhất có thể để phản ánh mục đích ban đầu của các 
                bên và các phần còn lại sẽ tiếp tục có đầy đủ hiệu lực. Việc website <strong>
                DcbLand.com</strong> không thể đòi hỏi hoặc buộc thực hiện chặt chẽ mọi điều 
                khoản của Điều khoản Thoả thuận này sẽ không được coi là sự khước từ điều khoản 
                hay quyền bất kỳ. Điều khoản Thoả thuận này sẽ được quản lý theo các luật của 
                địa phương sở tại của website <strong>DcbLand.com</strong> trừ phi có sự mâu 
                thuẫn các quy tắc của các luật, và bạn và website DcbLand.com đều phải phục 
                tùng quyền thực thi pháp lý duy nhất của toà án địa phương đó. Điều khoản Thoả 
                thuận này là dành riêng cho bạn và bạn không thể chuyển các quyền của bạn, hoặc 
                nghĩa vụ cho bất kỳ ai. Tất cả các logo, tên chi nhánh, các sản phẩm, tên thương 
                mại hay các nhãn hiệu dịch vụ xuất hiện ở đây có thể là các tên thương mại hay 
                các nhãn dịch vụ của các chủ sở hữu tương ứng của chúng. Các tham chiếu đến tên 
                thương mại bất kỳ, nhãn hiệu dịch vụ và các liên kết đến hoặc từ website <strong>
                DcbLand.com</strong> đều được thực hiện chặt chẽ để làm rõ và nhận dạng và 
                không cấu thành sự chứng thực của website <strong>DcbLand.com </strong>về các 
                sản phẩm, dịch vụ hoặc thông tin do người chủ sở hữu của tên thương mại, nhãn 
                dịch vụ, hoặc liên kết, đề nghị hoặc sự chứng thực của website DcbLand.com 
                đối với người sở hữu các sản phẩm, dịch vụ hoặc thông tin do người chủ sở hữu 
                của tên thương mại, nhãn dịch vụ, hoặc liên kết đó.</p>
        </div>
    </div>