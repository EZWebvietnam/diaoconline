<div class="body">
                        <div class="news-content">
                            <p><?php $about[0]['gioi_thieu']?></p>
                        </div>
                    </div>