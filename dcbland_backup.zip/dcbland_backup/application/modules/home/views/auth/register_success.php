<div id="light" class="pop_up">
    <div class="pop_up_main">
        <div class="headline"><h2>THÔNG BÁO</h2></div>
            
        <div class="pop_up_main_inner">
            <h5 class="hightlight">Đăng ký tài khoản thành công</h5>
            <div class="text">
                <p>Bạn có thể sử dụng username và password đã đăng ký để đăng nhập vào hệ thống.</p>
                <script language="javascript" type="text/javascript">
                    function redirect() {
                        window.setTimeout('window.location="/";', 5000);
                    }
                    redirect();
                </script>
            </div>

            <div id="p-load">
                <p style="text-align:center;"><img src="<?php echo base_url();?>template/home_ezwebvietnam/Content/loading.gif" /></p>
                <p>Trang thông báo sẽ tự động chuyển về trang chủ hoặc click <a href="/" class="info-link">vào đây</a> để về trang chủ.</p>
            </div>
		    <div class="contact_info">
                <p><strong>Bộ phận Tư vấn Dịch vụ DCBLand.COM</strong><br />
                Địa chỉ: 655 Luỹ Bán Bích,Phường Phú Thạnh, Quận Tân Phú,TP.HCM<br />
                Điện thoại: 0947098968</p>
            </div>
        </div>
               
    </div>
</div>