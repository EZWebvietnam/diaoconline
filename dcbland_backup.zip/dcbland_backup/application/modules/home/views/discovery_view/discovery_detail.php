<div class="col_770 margin_left">
            <div id="news_listing" class="news_form margin_bottom">
                <div class="rounded_style_2 rounded_box"><div class="TL"></div><div class="TR"></div><div class="BL"></div><div class="BR"></div>
                    <div class="unity_bar border_bottom">
                        <div class="left">
                            <div class="email_print">
                                <ul>
                                    <li><a href="javascript:window.print()" target="_blank">
                                        <span class="ico_16 ico_print_16"></span>Bản in</a></li>
                                    <li><a href="javascript:void(0)" onclick="GetDataSaved('<?php echo $detail_dis[0]['id_disco']?>','/kham-pha/the-gioi-kien-truc-c4/nha-nguyen-trong-may-noi-thoi-gian-ngung-dong-i45176','.itemsaved','2')" class="itemsaved">
                                        <span class="ico_16 ico_save_2_16"></span>Lưu tin</a></li>
                                    <li><a href="javascript:history.go(-1)"><span class="ico_16 ico_back_16"></span>Quay lại</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="right">
                                <div class="social_network">
        <span class="tl">Chia sẻ</span>
        <ul>
        <li><a href="http://www.facebook.com/share.php?u=<?php echo str_replace('//','/',base_url().$_SERVER['REQUEST_URI'])?>" target="_blank"><span class="ico_16 ico_facebook_16">facebook</span></a></li>

        
        </ul>
    </div>

                        </div>
                    </div>
    <div class="breadcrumb">
            <div itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                <a href="#" itemprop="url" title="Khám phá"><span itemprop="title">Khám phá</span></a>
»            </div>
            <div itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                <a href="<?php echo base_url();?>kham-pha-c/<?php echo mb_strtolower(url_title(removesign($detail_dis[0]['name'])));?>-c<?php echo $detail_dis[0]['id_cate']?>" itemprop="url" title="<?php echo $detail_dis[0]['name']?>"><span itemprop="title"><?php echo $detail_dis[0]['name']?></span></a>
            </div>
    </div>
                    <div class="body">
                        <h2 class="sub_title"></h2>
                        <h1 class="larger_title"><?php echo $detail_dis[0]['title']?></h1>
                        <span class="updated_date">Cập nhật <?php echo date('d/m/Y h:i',$detail_dis[0]['create_date'])?></span><br>
                        <div class="news-content">
                            <p>
                            <?php echo $detail_dis[0]['content']?>
</p>
    
                        </div>
                    </div>
                    <div class="unity_bar border_top">
                        <div class="left">
                            <div class="email_print">
                                <ul>
                                    <li><a href="javascript:window.print()">
                                        <span class="ico_16 ico_print_16"></span>Bản in</a></li>
                                    <li><a href="javascript:void(0)" onclick="GetDataSaved('hyWDobl1I+I=','/kham-pha/the-gioi-kien-truc-c4/nha-nguyen-trong-may-noi-thoi-gian-ngung-dong-i45176','.itemsaved','2')" class="itemsaved">
                                        <span class="ico_16 ico_save_2_16"></span>Lưu tin</a></li>
                                    <li><a href="javascript:history.go(-1)"><span class="ico_16 ico_back_16"></span>Quay lại</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="right">
                                <div class="social_network">
        <span class="tl">Chia sẻ</span>
        <ul>
        <li><a href="http://www.facebook.com/share.php?u=<?php echo str_replace('//','/',base_url().$_SERVER['REQUEST_URI'])?>" target="_blank"><span class="ico_16 ico_facebook_16">facebook</span></a></li>
        
        </ul>
    </div>

                        </div>
                    </div>
                </div>
            </div>
                <div id="latest_news_2" class="rounded_style_2 rounded_box margin_bottom"><div class="TL"></div><div class="TR"></div><div class="BL"></div><div class="BR"></div>
                    <div class="headline_3">
                        <h2>
                            CÁC TIN KHÁC</h2>
                    </div>
                    <div class="content">
                        <ul class="listing_3">
                        <?php 
                        foreach($list_other as $list)
                        {
                        ?>
                                <li><a href="<?php echo base_url();?>kham-pha/<?php echo mb_strtolower(url_title(removesign($list['name'])))?>-c<?php echo $list['id_cate']?>/<?php echo mb_strtolower(url_title(removesign($list['title'])));?>-i<?php echo $list['id_disco']?>">
                                <?php 
                                if(file_exists($_SERVER['DOCUMENT_ROOT'].ROT_DIR.'file/uploads/discovery/'.$list['img']))
                                {
                                ?>
                                    <img src="<?php echo base_url();?>file/uploads/discovery/<?php echo $list['img']?>" width="125" alt="<?php echo $list['title']?>">
                                    <?php } ?>
                                    </a>
                                    <h2>
                                        <a href="<?php echo base_url();?>kham-pha/<?php echo mb_strtolower(url_title(removesign($list['name'])))?>-c<?php echo $list['id_cate']?>/<?php echo mb_strtolower(url_title(removesign($list['title'])));?>-i<?php echo $list['id_disco']?>"><?php echo $list['title']?></a></h2>
                                    <span class="updated_date"><?php echo date('d/m/Y h:i',$list['create_date'])?></span> </li>
                        <?php } ?>        
                        </ul>
                    </div>
                </div>            </div>